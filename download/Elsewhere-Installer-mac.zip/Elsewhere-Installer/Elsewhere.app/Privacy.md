# Privacy Policy

Last updated: 27 November 2026

Elsewhere is made by Nimit Ahluwalia ("we", "us"). Short version: Elsewhere collects nothing about you on its own. Everything stays on your iPhone unless you choose to send it to us.

## What Elsewhere collects

Nothing, automatically. There are no accounts, no analytics, no advertising, no tracking and no cookies in the app.

## What stays on your iPhone

These are stored only on your iPhone and never sent to us:

- the locations you set, your saved places and routes, and recent searches
- the pairing that lets Elsewhere talk to your iPhone, kept in the iPhone's Keychain
- your access codes and plan status, kept in the Keychain
- the problem log

Search uses Apple Maps, so the text you search for is handled by Apple under Apple's privacy policy.

## What you choose to send us

If you answer the beta survey, your answers are sent to us without your name, email or location. If you ask a question inside Elsewhere, we receive your message, the setup details if you leave them switched on (your iOS version and what the help centre found, never your location), and your email only if you type one. A random secret kept on your iPhone is what lets only you read the reply. If you contact us or send feedback another way, we receive what you send: your message, the app and iOS versions, and the problem log. If you ask for your access back, we receive your iPhone's Elsewhere code (a random code made by the app, not your Apple ID or serial number). We use these only to help you, and never sell or share them.

## The website

elsewheres.live sets no cookies of its own and has no ads or trackers. It counts visits without cookies: each count is only the page that was opened and the website that linked to it, never who you are, your address or your device. If you join the beta list, we keep your email only to tell you when you can install Elsewhere, and delete it if you ask.

The checkout opens on top of our page but is run by Polar and its card processor, Stripe, who may set their own cookies to take the payment safely, under their own privacy policies.

## Payments

Purchases are handled by our payment provider. They collect what they need to take payment, such as your name, email address and card details, under their own privacy policy. We receive your name, email address and what you bought. We never see your card details.

## Website and cookies

Our website uses no tracking or advertising cookies. The payment checkout may use cookies it needs to work, under the payment provider's policy.

## Children

Elsewhere is not meant for children under 13.

## Deleting your data

Deleting Elsewhere removes most of its data. Items in the Keychain may stay until you reset your iPhone. To have us delete anything you sent us, use Contact Nims.

## Changes

If this policy changes, the date at the top changes. If Elsewhere ever starts sending anything new, it will ask you first.

## Contact

Use Contact Nims in Settings > Help centre.
