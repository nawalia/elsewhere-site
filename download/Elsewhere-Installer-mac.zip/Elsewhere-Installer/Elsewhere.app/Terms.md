# Terms of Use

Last updated: 24 November 2026

These terms are an agreement between you and Nimit Ahluwalia, who makes Elsewhere ("we", "us"). By installing or using Elsewhere you agree to them. If you don't agree, don't use Elsewhere.

## What Elsewhere is

Elsewhere sets your own iPhone's location using the location simulation tool Apple includes in iOS for developers. It only works on an iPhone you own or control, after you turn on Developer Mode and pair it yourself.

## Your responsibility

How you use Elsewhere is entirely up to you, and you are solely responsible for it. That includes following the laws where you are and the rules of any app or service you use while a location is set. We don't see or control what you do with Elsewhere, and we are not responsible for any result of your use, including anything that happens between you and other people, apps or services.

You agree to defend and hold us harmless from any claim, loss or cost that arises from your use of Elsewhere or from breaking these terms.

## No warranty

Elsewhere is provided "as is" and "as available", without warranties of any kind. We don't promise that it will work on every iPhone or iOS version, that it will hold a location without interruption, or that Apple won't change iOS in a way that stops it working.

## Limit of liability

As far as the law allows, we are not liable for any indirect, incidental, special or consequential loss, or for lost data, profits or opportunities. Our total liability for any claim is limited to the amount you paid for Elsewhere in the 12 months before the claim.

## Your licence

We give you a personal, non-transferable licence to use Elsewhere on your own iPhone. You may not resell, rent or redistribute Elsewhere; share, sell or publish codes or licence keys made for you; copy, decompile or alter the app; or get around its access checks in any way.

## Codes and purchases

A code works once per iPhone. A code made for one iPhone only works on that iPhone. Time-based access adds up; if you already have lifetime access, a further code is refused and stays unused. Monthly plans are not refundable; lifetime purchases can be refunded within 14 days, as set out in the Refund Policy. Getting access by fraud, chargebacks, sharing codes or keys, changing the iPhone's clock, or any other way of getting around Elsewhere's access checks breaks these terms.

## Breaking these terms

If you break these terms, including by copying, sharing, reselling or cracking Elsewhere or its codes, we may take legal action against you. That can include claims for damages, our legal costs, and court orders to stop. You agree that the courts of California have jurisdiction over such claims.

## Beta

While Elsewhere is in beta it is free, and features may change or be removed.

## Changes

We may update these terms. The date at the top shows the latest version. Using Elsewhere after a change means you accept the new terms.

## Law

These terms are governed by the laws of the State of California, USA.

## Contact

Use Contact Nims in Settings > Help centre.
