# Refund Policy

Last updated: 24 November 2026

Every plan starts with a free trial, so you can check that Elsewhere works on your iPhone before you pay.

## Monthly plans

Monthly plans are not refundable. You can cancel at any time and keep access until the end of the month you paid for.

## Lifetime

You can ask for a full refund of a lifetime purchase within 14 days of buying it. After 14 days, lifetime purchases are not refundable.

## How refunds work

Refunds go back to the payment method you used. When a purchase is refunded, the access it gave ends and its code or licence key stops working. A chargeback made instead of asking us for a refund is treated the same way.

Nothing in this policy limits any refund right you have under the law where you live.

## Help

For a refund or anything else, use Contact Nims in Settings > Help centre.
