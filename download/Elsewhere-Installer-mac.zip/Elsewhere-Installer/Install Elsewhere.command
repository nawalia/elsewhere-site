#!/bin/sh
# Double-click to install Elsewhere on the iPhone plugged into this Mac.
# You type your own Apple ID; the password goes only to Apple and is never saved.
cd "$(dirname "$0")"
xattr -dr com.apple.quarantine . 2>/dev/null
clear
echo "Elsewhere Installer"
echo "-------------------"
echo "1. Plug your iPhone into this Mac with a cable and unlock it."
echo "2. If the iPhone asks, tap Trust."
echo ""
./elsewhere install Elsewhere.app
echo ""
echo "Next, on the iPhone: Settings > General > VPN & Device Management > trust your Apple ID,"
echo "then open Elsewhere and follow Setup. You can close this window."
read -r _
